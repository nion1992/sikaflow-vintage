/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as auth from "../auth.js";
import type * as auth_emailOtp from "../auth/emailOtp.js";
import type * as authz from "../authz.js";
import type * as backupsData from "../backupsData.js";
import type * as billing from "../billing.js";
import type * as businesses from "../businesses.js";
import type * as crons from "../crons.js";
import type * as customers from "../customers.js";
import type * as customersServer from "../customersServer.js";
import type * as docMath from "../docMath.js";
import type * as followups from "../followups.js";
import type * as http from "../http.js";
import type * as invoices from "../invoices.js";
import type * as payments from "../payments.js";
import type * as products from "../products.js";
import type * as qr from "../qr.js";
import type * as quotes from "../quotes.js";
import type * as reports from "../reports.js";
import type * as shared from "../shared.js";
import type * as stripe from "../stripe.js";
import type * as supabaseSync from "../supabaseSync.js";
import type * as text from "../text.js";
import type * as users from "../users.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  auth: typeof auth;
  "auth/emailOtp": typeof auth_emailOtp;
  authz: typeof authz;
  backupsData: typeof backupsData;
  billing: typeof billing;
  businesses: typeof businesses;
  crons: typeof crons;
  customers: typeof customers;
  customersServer: typeof customersServer;
  docMath: typeof docMath;
  followups: typeof followups;
  http: typeof http;
  invoices: typeof invoices;
  payments: typeof payments;
  products: typeof products;
  qr: typeof qr;
  quotes: typeof quotes;
  reports: typeof reports;
  shared: typeof shared;
  stripe: typeof stripe;
  supabaseSync: typeof supabaseSync;
  text: typeof text;
  users: typeof users;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
